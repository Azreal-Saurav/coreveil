import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-additional-details.ts';
import '@/ai/flows/generate-testimonial-summary.ts';
import '@/ai/flows/website-chatbot.ts';
