import {genkit} from 'genkit';

export const ai = genkit({
  plugins: [],
  model: 'googleai/gemini-2.5-flash',
});
