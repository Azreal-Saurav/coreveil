import ContactSection from "@/components/core-ai/contact-section";

export default function ContactPage() {
  return (
    <ContactSection />
  );
}
