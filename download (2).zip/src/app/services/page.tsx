import ServicesSection from "@/components/core-ai/services-section";

export default function ServicesPage() {
  return (
    <ServicesSection />
  );
}
